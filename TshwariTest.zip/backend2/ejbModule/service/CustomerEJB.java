package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;

import model.CustomerEntity;

/**
 * Session Bean implementation class CustomerEJB
 */
@Stateless
@LocalBean
public class CustomerEJB {

    private EntityManager em;
    public CustomerEJB() {
        // TODO Auto-generated constructor stub
    }
    
    public void addNew(CustomerEntity employeeEntity) {
    	System.out.println("****************Adding*****************");
    	em.persist(employeeEntity);
    }

}
